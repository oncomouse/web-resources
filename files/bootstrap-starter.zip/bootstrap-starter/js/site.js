(function($) {
	$(function() {
		// Code to run on page load goes here.
	});
})(jQuery);